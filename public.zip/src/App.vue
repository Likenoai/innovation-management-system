<script setup>
import './api/interceptors.js';
</script>

<template>
	<router-view></router-view>
</template>

<style scoped></style>
