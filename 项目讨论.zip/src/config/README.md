权限管理要配置三个地方

1. @/router/index.js

路由映射

2. @/config/permissions.js

角色对应的权限

3. @/config/menu.js

aside 菜单配置
